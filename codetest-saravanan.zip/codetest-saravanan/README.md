# phpcodetest
Instructions:

This project developend in Laravel framework

To run this,

Import the live_test.sql in your MySQL DB

In CMD line,
cd myapp
composer update -0

Import test_postman_collection.json Postman collection for easy referrance. ppsshop.com is my virtualhost. replace with your own 
